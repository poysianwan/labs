const BASE = '/api'

let _token = null
export const setToken = (t) => { _token = t }
export const clearToken = () => { _token = null }

const headers = () => ({
  'Content-Type': 'application/json',
  ..._token ? { Authorization: `Bearer ${_token}` } : {}
})

const handle = async (res) => {
  const data = await res.json()
  if (!res.ok) throw Object.assign(new Error(data.error || 'API_ERROR'), data)
  return data
}

export const api = {
  login: (pin) => fetch(`${BASE}/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pin }) }).then(handle),
  logout: () => fetch(`${BASE}/auth/logout`, { method: 'POST', headers: headers() }).then(handle),
  snapshot: () => fetch(`${BASE}/sync/snapshot`, { headers: headers() }).then(handle),
  syncOrders: (orders) => fetch(`${BASE}/sync/orders`, { method: 'POST', headers: headers(), body: JSON.stringify({ orders }) }).then(handle),
  createOrder: (order) => fetch(`${BASE}/orders`, { method: 'POST', headers: headers(), body: JSON.stringify(order) }).then(handle),
  getOrders: (params = {}) => fetch(`${BASE}/orders?${new URLSearchParams(params)}`, { headers: headers() }).then(handle),
  voidOrder: (id, reason) => fetch(`${BASE}/orders/${id}/void`, { method: 'PUT', headers: headers(), body: JSON.stringify({ reason }) }).then(handle),
  getIngredients: () => fetch(`${BASE}/inventory`, { headers: headers() }).then(handle),
  restock: (id, quantity, note) => fetch(`${BASE}/inventory/${id}/restock`, { method: 'POST', headers: headers(), body: JSON.stringify({ quantity, note }) }).then(handle),
  getProducts: () => fetch(`${BASE}/inventory/products`, { headers: headers() }).then(handle),
  updateProduct: (id, data) => fetch(`${BASE}/inventory/products/${id}`, { method: 'PUT', headers: headers(), body: JSON.stringify(data) }).then(handle),
  getRecipe: (id) => fetch(`${BASE}/inventory/products/${id}/recipe`, { headers: headers() }).then(handle),
  updateRecipe: (id, ingredients) => fetch(`${BASE}/inventory/products/${id}/recipe`, { method: 'PUT', headers: headers(), body: JSON.stringify({ ingredients }) }).then(handle),
  startShift: (opening_cash) => fetch(`${BASE}/reports/shifts/start`, { method: 'POST', headers: headers(), body: JSON.stringify({ opening_cash }) }).then(handle),
  endShift: (id, closing_cash) => fetch(`${BASE}/reports/shifts/${id}/end`, { method: 'POST', headers: headers(), body: JSON.stringify({ closing_cash }) }).then(handle),
  getSalesReport: (from, to) => fetch(`${BASE}/reports/sales?${new URLSearchParams({ from, to })}`, { headers: headers() }).then(handle),
}
