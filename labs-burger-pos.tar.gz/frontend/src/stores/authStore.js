import { create } from 'zustand'

export const useAuthStore = create((set, get) => ({
  user: null,
  token: null,

  login: (user, token) => {
    set({ user, token })
    // Auto-logout after 12h
    setTimeout(() => get().logout(), 12 * 60 * 60 * 1000)
  },

  logout: () => set({ user: null, token: null }),

  isAdmin: () => get().user?.role === 'admin',
  isCashier: () => get().user?.role === 'cashier',
}))
