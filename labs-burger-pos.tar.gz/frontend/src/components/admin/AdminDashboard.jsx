import { useState, useEffect } from 'react'
import { Routes, Route, NavLink, useNavigate } from 'react-router-dom'
import { useAuthStore } from '../../stores/authStore.js'
import { api } from '../../utils/apiClient.js'
import SalesReport from './SalesReport.jsx'
import InventoryPanel from './InventoryPanel.jsx'

export default function AdminDashboard() {
  const { user, logout } = useAuthStore()
  const navigate = useNavigate()

  const navStyle = (isActive) => ({
    display: 'flex', alignItems: 'center', gap: 10,
    padding: '12px 20px', fontSize: 14, fontWeight: 600,
    color: isActive ? '#FFD700' : '#666',
    background: isActive ? '#1a0000' : 'transparent',
    borderLeft: `3px solid ${isActive ? '#CC0000' : 'transparent'}`,
    textDecoration: 'none', transition: 'all 0.15s'
  })

  return (
    <div style={{ display: 'flex', height: '100%', background: '#0f0f0f' }}>

      {/* Sidebar */}
      <div style={{ width: 200, background: '#141414', borderRight: '1px solid #2a2a2a', display: 'flex', flexDirection: 'column' }}>
        <div style={{ padding: '20px', borderBottom: '1px solid #222' }}>
          <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 22, color: '#CC0000' }}>LABS BURGER</div>
          <div style={{ fontSize: 11, color: '#555', marginTop: 2 }}>Admin Dashboard</div>
        </div>

        <nav style={{ flex: 1, paddingTop: 8 }}>
          <NavLink to="/admin/sales" style={({ isActive }) => navStyle(isActive)}>
            📊 Sales
          </NavLink>
          <NavLink to="/admin/inventory" style={({ isActive }) => navStyle(isActive)}>
            📦 Inventory
          </NavLink>
          <NavLink to="/admin/orders" style={({ isActive }) => navStyle(isActive)}>
            🧾 Orders
          </NavLink>
        </nav>

        <div style={{ padding: 16, borderTop: '1px solid #222' }}>
          <div style={{ fontSize: 12, color: '#555', marginBottom: 8 }}>{user?.name}</div>
          <button
            onClick={() => navigate('/pos')}
            style={{ width: '100%', padding: '8px', background: '#CC0000', color: '#fff', borderRadius: 8, fontSize: 12, fontWeight: 700, marginBottom: 8 }}
          >
            ← Back to POS
          </button>
          <button
            onClick={() => { logout(); navigate('/login') }}
            style={{ width: '100%', padding: '8px', background: '#1a1a1a', color: '#666', borderRadius: 8, fontSize: 12 }}
          >
            Logout
          </button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, overflow: 'auto' }}>
        <Routes>
          <Route path="sales" element={<SalesReport />} />
          <Route path="inventory" element={<InventoryPanel />} />
          <Route path="orders" element={<OrdersPanel />} />
          <Route path="*" element={<SalesReport />} />
        </Routes>
      </div>
    </div>
  )
}

function OrdersPanel() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [date, setDate] = useState(new Date().toISOString().split('T')[0])

  useEffect(() => {
    const load = async () => {
      setLoading(true)
      try { const data = await api.getOrders({ date }); setOrders(data) }
      catch { setOrders([]) }
      finally { setLoading(false) }
    }
    load()
  }, [date])

  const handleVoid = async (id) => {
    const reason = prompt('Void reason:')
    if (!reason) return
    try {
      await api.voidOrder(id, reason)
      setOrders(o => o.filter(x => x.id !== id))
    } catch (e) { alert('Failed to void: ' + e.message) }
  }

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
        <h2 style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 28, color: '#FFD700' }}>Orders</h2>
        <input type="date" value={date} onChange={e => setDate(e.target.value)}
          style={{ background: '#1a1a1a', border: '1px solid #333', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 13 }} />
      </div>

      {loading ? <div style={{ color: '#555' }}>Loading...</div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          {orders.map(order => (
            <div key={order.id} style={{ background: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: 10, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 20, color: '#CC0000', minWidth: 80 }}>{order.order_number}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: '#ccc' }}>{order.cashier} · {order.dining_type}</div>
                <div style={{ fontSize: 11, color: '#555' }}>{new Date(order.created_at).toLocaleTimeString('en-PH')}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 20, color: '#FFD700' }}>₱{parseFloat(order.total).toFixed(2)}</div>
                <div style={{ fontSize: 11, color: order.payment_method === 'gcash' ? '#60a5fa' : '#86efac' }}>{order.payment_method?.toUpperCase()}</div>
              </div>
              <button onClick={() => handleVoid(order.id)}
                style={{ padding: '6px 12px', background: '#1a0000', color: '#CC0000', border: '1px solid #CC0000', borderRadius: 6, fontSize: 12 }}>
                Void
              </button>
            </div>
          ))}
          {orders.length === 0 && <div style={{ color: '#444', fontSize: 14 }}>No orders for this date.</div>}
        </div>
      )}
    </div>
  )
}
