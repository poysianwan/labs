import { useState, useEffect } from 'react'
import { api } from '../../utils/apiClient.js'

export default function InventoryPanel() {
  const [ingredients, setIngredients] = useState([])
  const [loading, setLoading] = useState(true)
  const [restocking, setRestocking] = useState(null)
  const [restockQty, setRestockQty] = useState('')
  const [restockNote, setRestockNote] = useState('')

  const load = async () => {
    setLoading(true)
    try { setIngredients(await api.getIngredients()) }
    catch { setIngredients([]) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const handleRestock = async () => {
    if (!restockQty || parseFloat(restockQty) <= 0) return
    try {
      await api.restock(restocking.id, parseFloat(restockQty), restockNote || 'manual restock')
      setRestocking(null); setRestockQty(''); setRestockNote('')
      await load()
    } catch (e) { alert('Restock failed: ' + e.message) }
  }

  const lowStock = ingredients.filter(i => i.is_low)

  return (
    <div style={{ padding: 24 }}>
      <h2 style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 28, color: '#FFD700', marginBottom: 20 }}>Inventory</h2>

      {/* Low stock alert */}
      {lowStock.length > 0 && (
        <div style={{ background: '#1a0a00', border: '1px solid #7c3900', borderRadius: 12, padding: '14px 18px', marginBottom: 20 }}>
          <div style={{ fontSize: 13, color: '#f97316', fontWeight: 700, marginBottom: 8 }}>⚠ Low stock alert ({lowStock.length})</div>
          <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
            {lowStock.map(i => (
              <span key={i.id} style={{ fontSize: 12, background: '#2a1000', color: '#f97316', padding: '4px 10px', borderRadius: 20, border: '1px solid #7c3900' }}>
                {i.name} — {parseFloat(i.current_stock).toFixed(0)} {i.unit}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Ingredients table */}
      {loading ? <div style={{ color: '#555' }}>Loading...</div> : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
          {/* Header */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 120px 80px 120px', gap: 12, padding: '8px 16px', fontSize: 11, color: '#555', fontWeight: 600, textTransform: 'uppercase', letterSpacing: .05 }}>
            <span>Ingredient</span><span>Stock</span><span>Unit</span><span>Alert at</span>
          </div>

          {ingredients.map(ing => (
            <div key={ing.id} style={{
              display: 'grid', gridTemplateColumns: '1fr 120px 80px 120px', gap: 12,
              background: ing.is_low ? '#1a0a00' : '#1a1a1a',
              border: `1px solid ${ing.is_low ? '#7c3900' : '#2a2a2a'}`,
              borderRadius: 10, padding: '14px 16px', alignItems: 'center'
            }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 600, color: ing.is_low ? '#f97316' : '#ddd' }}>{ing.name}</div>
              </div>
              <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 22, color: ing.is_low ? '#f97316' : '#FFD700' }}>
                {parseFloat(ing.current_stock).toFixed(0)}
              </div>
              <div style={{ fontSize: 12, color: '#555' }}>{ing.unit}</div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: 12, color: '#555' }}>{parseFloat(ing.low_stock_alert).toFixed(0)}</span>
                <button
                  onClick={() => { setRestocking(ing); setRestockQty(''); setRestockNote('') }}
                  style={{ padding: '5px 12px', background: '#CC0000', color: '#fff', borderRadius: 6, fontSize: 12, fontWeight: 700 }}
                >
                  + Restock
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Restock modal */}
      {restocking && (
        <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.8)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 200 }}>
          <div style={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 16, padding: 28, width: 340 }}>
            <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 24, color: '#FFD700', marginBottom: 4 }}>Restock</div>
            <div style={{ fontSize: 13, color: '#888', marginBottom: 20 }}>{restocking.name} — current: {parseFloat(restocking.current_stock).toFixed(0)} {restocking.unit}</div>

            <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>Quantity to add</label>
            <input
              type="number" min="1" value={restockQty} onChange={e => setRestockQty(e.target.value)}
              placeholder={`Amount in ${restocking.unit}`}
              style={{ width: '100%', background: '#111', border: '1px solid #333', color: '#fff', padding: '12px', borderRadius: 8, fontSize: 16, marginBottom: 12 }}
              autoFocus
            />

            <label style={{ fontSize: 12, color: '#666', display: 'block', marginBottom: 4 }}>Note (optional)</label>
            <input
              value={restockNote} onChange={e => setRestockNote(e.target.value)}
              placeholder="e.g. delivery from supplier"
              style={{ width: '100%', background: '#111', border: '1px solid #333', color: '#fff', padding: '10px', borderRadius: 8, fontSize: 14, marginBottom: 20 }}
            />

            <div style={{ display: 'flex', gap: 10 }}>
              <button onClick={() => setRestocking(null)}
                style={{ flex: 1, padding: 12, background: '#252525', color: '#888', borderRadius: 10, fontSize: 14 }}>
                Cancel
              </button>
              <button onClick={handleRestock} disabled={!restockQty}
                style={{ flex: 1, padding: 12, background: '#CC0000', color: '#fff', borderRadius: 10, fontSize: 14, fontWeight: 700, opacity: restockQty ? 1 : 0.5 }}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
