import { useState, useEffect } from 'react'
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts'
import { api } from '../../utils/apiClient.js'

export default function SalesReport() {
  const [report, setReport] = useState(null)
  const [loading, setLoading] = useState(true)
  const [from, setFrom] = useState(new Date().toISOString().split('T')[0])
  const [to, setTo] = useState(new Date().toISOString().split('T')[0])

  const load = async () => {
    setLoading(true)
    try { setReport(await api.getSalesReport(from, to)) }
    catch { setReport(null) }
    finally { setLoading(false) }
  }

  useEffect(() => { load() }, [])

  const stat = (label, value, sub) => (
    <div style={{ background: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: 12, padding: 20 }}>
      <div style={{ fontSize: 12, color: '#666', marginBottom: 6 }}>{label}</div>
      <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 36, color: '#FFD700', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: '#555', marginTop: 4 }}>{sub}</div>}
    </div>
  )

  return (
    <div style={{ padding: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 24, flexWrap: 'wrap' }}>
        <h2 style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 28, color: '#FFD700' }}>Sales Report</h2>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <input type="date" value={from} onChange={e => setFrom(e.target.value)}
            style={{ background: '#1a1a1a', border: '1px solid #333', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 13 }} />
          <span style={{ color: '#555' }}>to</span>
          <input type="date" value={to} onChange={e => setTo(e.target.value)}
            style={{ background: '#1a1a1a', border: '1px solid #333', color: '#fff', padding: '8px 12px', borderRadius: 8, fontSize: 13 }} />
          <button onClick={load}
            style={{ padding: '8px 18px', background: '#CC0000', color: '#fff', borderRadius: 8, fontSize: 13, fontWeight: 700 }}>
            Apply
          </button>
        </div>
      </div>

      {loading ? <div style={{ color: '#555' }}>Loading report...</div> : !report ? (
        <div style={{ color: '#555' }}>No data available.</div>
      ) : (
        <>
          {/* Stats */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(180px, 1fr))', gap: 12, marginBottom: 24 }}>
            {stat('Total orders', report.total_orders)}
            {stat('Total revenue', `₱${parseFloat(report.total_revenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2 })}`)}
            {stat('Cash collected', `₱${parseFloat(report.cash_revenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2 })}`, 'Cash payments')}
            {stat('GCash collected', `₱${parseFloat(report.gcash_revenue || 0).toLocaleString('en-PH', { minimumFractionDigits: 2 })}`, 'GCash payments')}
          </div>

          {/* Hourly chart */}
          {report.hourly?.length > 0 && (
            <div style={{ background: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: 12, padding: 20, marginBottom: 24 }}>
              <div style={{ fontSize: 13, color: '#888', marginBottom: 16 }}>Orders by hour</div>
              <ResponsiveContainer width="100%" height={180}>
                <BarChart data={report.hourly}>
                  <XAxis dataKey="hour" tick={{ fill: '#555', fontSize: 11 }} tickFormatter={h => `${h}:00`} />
                  <YAxis tick={{ fill: '#555', fontSize: 11 }} />
                  <Tooltip
                    contentStyle={{ background: '#1a1a1a', border: '1px solid #333', borderRadius: 8, color: '#fff', fontSize: 12 }}
                    formatter={(v) => [v, 'Orders']}
                    labelFormatter={(h) => `${h}:00`}
                  />
                  <Bar dataKey="orders" radius={[4, 4, 0, 0]}>
                    {report.hourly.map((_, i) => <Cell key={i} fill="#CC0000" />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}

          {/* Top products */}
          {report.top_products?.length > 0 && (
            <div style={{ background: '#1a1a1a', border: '1px solid #2a2a2a', borderRadius: 12, padding: 20 }}>
              <div style={{ fontSize: 13, color: '#888', marginBottom: 16 }}>Top products</div>
              {report.top_products.map((p, i) => (
                <div key={p.name} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '10px 0', borderBottom: '1px solid #222' }}>
                  <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 20, color: '#CC0000', minWidth: 28 }}>#{i + 1}</div>
                  <div style={{ flex: 1, fontSize: 14, color: '#ddd' }}>{p.name}</div>
                  <div style={{ fontSize: 13, color: '#888' }}>{p.qty_sold} sold</div>
                  <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 18, color: '#FFD700' }}>₱{parseFloat(p.revenue).toLocaleString('en-PH', { minimumFractionDigits: 2 })}</div>
                </div>
              ))}
            </div>
          )}
        </>
      )}
    </div>
  )
}
