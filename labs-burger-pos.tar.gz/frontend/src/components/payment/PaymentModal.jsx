import { useState } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { api } from '../../utils/api.js'
import { useAuthStore } from '../../stores/authStore.js'
import { saveOrderOffline, markOrderSynced } from '../../db/index.js'
import { useSyncStore } from '../../stores/syncStore.js'

const NUMPAD = ['7','8','9','4','5','6','1','2','3','←','0','.']
const QUICK_CASH = [20,50,100,200,500,1000]

export default function PaymentModal({ total, items, diningType, shiftId, onClose, onSuccess }) {
  const [method, setMethod] = useState('cash')
  const [amountStr, setAmountStr] = useState('')
  const [referenceNote, setReferenceNote] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [done, setDone] = useState(null)
  const token = useAuthStore(s => s.token)
  const user = useAuthStore(s => s.user)
  const isOnline = useSyncStore(s => s.isOnline)

  const amount = parseFloat(amountStr) || 0
  const change = method === 'cash' ? Math.max(0, amount - total) : 0
  const canPay = method === 'gcash' ? true : amount >= total

  const handleNum = (key) => {
    if (key === '←') { setAmountStr(s => s.slice(0,-1)); return }
    if (key === '.' && amountStr.includes('.')) return
    if (amountStr.length >= 8) return
    setAmountStr(s => s + key)
  }

  const handlePay = async () => {
    if (!canPay || loading) return
    setLoading(true); setError('')
    const orderId = uuidv4()
    const now = new Date().toISOString()

    const orderPayload = {
      id: orderId,
      user_id: user.id,
      shift_id: shiftId,
      dining_type: diningType,
      items: items.map(i => ({ product_id: i.product_id, quantity: i.quantity, unit_price: i.unit_price, notes: i.notes || null })),
      payment: { method, amount: method === 'cash' ? amount : total, change_given: change, reference_note: referenceNote || null },
      created_at: now
    }

    // Always save locally first
    await saveOrderOffline(orderPayload)

    // Try to sync if online
    if (isOnline) {
      try {
        await api.orders.create(orderPayload, token)
        await markOrderSynced(orderId)
      } catch (err) {
        if (err.code === 'DUPLICATE_ORDER') await markOrderSynced(orderId)
        else if (err.code === 'INSUFFICIENT_STOCK') {
          setError(`Out of stock: ${err.data?.ingredient}`)
          setLoading(false); return
        }
        // Other errors: stays in offline queue
      }
    }

    setDone({ change, method, total })
    setLoading(false)
  }

  if (done) {
    return (
      <div style={{
        position:'absolute',inset:0,zIndex:100,
        background:'rgba(0,0,0,0.85)',display:'flex',
        alignItems:'center',justifyContent:'center'
      }}>
        <div style={{
          background:'var(--black-card)',border:'1px solid var(--green)',
          borderRadius:'var(--radius)',padding:40,textAlign:'center',
          maxWidth:320,width:'90%'
        }}>
          <div style={{fontSize:48,marginBottom:16}}>✅</div>
          <div style={{fontFamily:'var(--font-display)',fontSize:32,color:'var(--green)',letterSpacing:2}}>ORDER PLACED</div>
          {done.method==='cash'&&done.change>0&&(
            <div style={{marginTop:16}}>
              <div style={{fontSize:14,color:'var(--gray)'}}>Change</div>
              <div style={{fontFamily:'var(--font-display)',fontSize:48,color:'var(--yellow)'}}>₱{done.change.toFixed(2)}</div>
            </div>
          )}
          {done.method==='gcash'&&(
            <div style={{marginTop:12,fontSize:14,color:'var(--gray)'}}>GCash payment recorded</div>
          )}
          <button onClick={onSuccess} style={{
            marginTop:24,width:'100%',height:52,
            background:'var(--green)',color:'var(--white)',
            fontSize:16,fontWeight:700,borderRadius:'var(--radius-sm)'
          }}>New Order</button>
        </div>
      </div>
    )
  }

  return (
    <div style={{
      position:'absolute',inset:0,zIndex:100,
      background:'rgba(0,0,0,0.85)',display:'flex',
      alignItems:'center',justifyContent:'center'
    }}>
      <div style={{
        background:'var(--black-card)',border:'1px solid var(--black-border)',
        borderRadius:'var(--radius)',width:420,maxHeight:'90dvh',
        overflow:'auto',display:'flex',flexDirection:'column'
      }}>
        {/* Header */}
        <div style={{padding:'20px 24px',borderBottom:'1px solid var(--black-border)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
          <div>
            <div style={{fontFamily:'var(--font-display)',fontSize:24,letterSpacing:2}}>PAYMENT</div>
            <div style={{color:'var(--yellow)',fontSize:28,fontFamily:'var(--font-display)'}}>₱{total.toFixed(2)}</div>
          </div>
          <button onClick={onClose} style={{background:'none',color:'var(--gray)',fontSize:24,padding:8}}>✕</button>
        </div>

        {/* Method selector */}
        <div style={{display:'flex',gap:12,padding:'16px 24px',borderBottom:'1px solid var(--black-border)'}}>
          {['cash','gcash'].map(m=>(
            <button key={m} onClick={()=>{setMethod(m);setAmountStr('')}} style={{
              flex:1,height:52,fontSize:16,fontWeight:700,borderRadius:'var(--radius-sm)',
              background:method===m?'var(--red)':'var(--black-soft)',
              color:method===m?'var(--white)':'var(--gray)',
              border:`1.5px solid ${method===m?'var(--red)':'var(--black-border)'}`,
              transition:'all 0.15s',textTransform:'uppercase',letterSpacing:1
            }}>{m}</button>
          ))}
        </div>

        {/* Cash input area */}
        {method==='cash'&&(
          <div style={{padding:'16px 24px',borderBottom:'1px solid var(--black-border)'}}>
            {/* Amount display */}
            <div style={{
              background:'var(--black)',border:'1px solid var(--black-border)',
              borderRadius:'var(--radius-sm)',padding:'12px 16px',
              textAlign:'right',marginBottom:12
            }}>
              <div style={{fontSize:12,color:'var(--gray)',marginBottom:4}}>Amount tendered</div>
              <div style={{fontFamily:'var(--font-display)',fontSize:36,color:'var(--white)',letterSpacing:2}}>
                ₱{amountStr||'0'}
              </div>
            </div>
            {/* Quick cash */}
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:6,marginBottom:12}}>
              {QUICK_CASH.map(v=>(
                <button key={v} onClick={()=>setAmountStr(String(v))} style={{
                  padding:'8px 0',fontSize:14,fontWeight:600,
                  background:'var(--black-soft)',color:'var(--white)',
                  border:'1px solid var(--black-border)',borderRadius:8,
                  opacity:v>=total?1:0.5
                }}>₱{v}</button>
              ))}
            </div>
            {/* Numpad */}
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
              {NUMPAD.map(k=>(
                <button key={k} onClick={()=>handleNum(k)} style={{
                  height:52,fontSize:k==='←'?20:22,fontWeight:700,
                  background:'var(--black-soft)',color:'var(--white)',
                  border:'1px solid var(--black-border)',borderRadius:'var(--radius-sm)'
                }}>{k}</button>
              ))}
            </div>
            {/* Change */}
            {amount>0&&amount>=total&&(
              <div style={{
                marginTop:12,padding:'10px 16px',
                background:'rgba(34,197,94,0.1)',borderRadius:8,
                border:'1px solid rgba(34,197,94,0.3)',
                display:'flex',justifyContent:'space-between',alignItems:'center'
              }}>
                <span style={{color:'var(--green)',fontWeight:600}}>Change</span>
                <span style={{fontFamily:'var(--font-display)',fontSize:24,color:'var(--green)'}}>₱{change.toFixed(2)}</span>
              </div>
            )}
          </div>
        )}

        {/* GCash note */}
        {method==='gcash'&&(
          <div style={{padding:'16px 24px',borderBottom:'1px solid var(--black-border)'}}>
            <div style={{
              background:'rgba(255,208,0,0.08)',border:'1px solid rgba(255,208,0,0.2)',
              borderRadius:8,padding:'12px 16px',marginBottom:12,fontSize:13,
              color:'var(--gray)',lineHeight:1.6
            }}>
              Ask customer to scan the GCash QR code posted at the counter and send ₱{total.toFixed(2)}.
            </div>
            <input
              value={referenceNote}
              onChange={e=>setReferenceNote(e.target.value)}
              placeholder="Sender name (optional)"
              style={{
                width:'100%',background:'var(--black-soft)',
                border:'1px solid var(--black-border)',borderRadius:8,
                padding:'12px 16px',color:'var(--white)',fontSize:14
              }}
            />
          </div>
        )}

        {error&&<div style={{padding:'8px 24px',color:'#ff6b6b',fontSize:13,background:'rgba(204,0,0,0.1)'}}>{error}</div>}

        {/* Confirm */}
        <div style={{padding:'16px 24px'}}>
          <button onClick={handlePay} disabled={!canPay||loading} style={{
            width:'100%',height:60,fontSize:18,fontWeight:700,
            background:canPay?'var(--red)':'var(--black-soft)',
            color:canPay?'var(--white)':'var(--gray)',
            borderRadius:'var(--radius)',border:'none',letterSpacing:1,
            transition:'all 0.15s',opacity:loading?0.7:1
          }}>
            {loading?'Processing...':isOnline?'CONFIRM PAYMENT':'SAVE OFFLINE'}
          </button>
        </div>
      </div>
    </div>
  )
}
