import { useState } from 'react'
import { api } from '../../utils/api.js'
import { useAuthStore } from '../../stores/authStore.js'
import { cacheProducts, cacheCategories, cacheIngredients } from '../../db/index.js'

const KEYS = ['1','2','3','4','5','6','7','8','9','←','0','✓']

export default function LoginScreen() {
  const [pin, setPin] = useState('')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const login = useAuthStore(s => s.login)

  const handleKey = async (key) => {
    if (loading) return
    if (key === '←') { setPin(p => p.slice(0, -1)); setError(''); return }
    if (key === '✓') {
      if (pin.length < 4) { setError('Enter your PIN'); return }
      setLoading(true); setError('')
      try {
        const { token, user } = await api.auth.login(pin)
        const snap = await api.sync.snapshot(token)
        await cacheProducts(snap.products)
        await cacheCategories(snap.categories)
        await cacheIngredients(snap.ingredients)
        login(user, token)
      } catch (err) {
        setError(err.code === 'INVALID_PIN' ? 'Wrong PIN. Try again.' : 'Connection error.')
        setPin('')
      } finally { setLoading(false) }
      return
    }
    if (pin.length >= 6) return
    setPin(p => p + key)
  }

  return (
    <div style={{
      height:'100dvh',display:'flex',flexDirection:'column',
      alignItems:'center',justifyContent:'center',
      background:'linear-gradient(160deg,#1a0000 0%,#111 60%)',gap:32
    }}>
      <div style={{textAlign:'center'}}>
        <div style={{fontFamily:'var(--font-display)',fontSize:56,color:'var(--yellow)',letterSpacing:4,lineHeight:1}}>LABS</div>
        <div style={{fontFamily:'var(--font-display)',fontSize:28,color:'var(--white)',letterSpacing:8}}>BURGER</div>
        <div style={{width:60,height:3,background:'var(--red)',margin:'12px auto 0',borderRadius:2}}/>
      </div>
      <div style={{display:'flex',gap:12,alignItems:'center',minHeight:24}}>
        {[0,1,2,3,4,5].map(i=>(
          <div key={i} style={{
            width:16,height:16,borderRadius:'50%',transition:'background 0.15s',
            background:i<pin.length?'var(--yellow)':'var(--black-border)',
            boxShadow:i<pin.length?'0 0 8px rgba(255,208,0,0.5)':'none'
          }}/>
        ))}
      </div>
      {error&&<div style={{color:'#ff6b6b',fontSize:14,fontWeight:500,background:'rgba(204,0,0,0.15)',padding:'8px 20px',borderRadius:8,border:'1px solid rgba(204,0,0,0.3)'}}>{error}</div>}
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:12,width:280}}>
        {KEYS.map(key=>{
          const isConfirm=key==='✓',isBack=key==='←'
          return(
            <button key={key} onClick={()=>handleKey(key)} disabled={loading} style={{
              height:72,fontSize:isConfirm||isBack?22:28,fontWeight:700,
              background:isConfirm&&pin.length>=4?'var(--red)':'var(--black-card)',
              color:isConfirm&&pin.length<4?'var(--gray)':'var(--white)',
              border:`1px solid ${isConfirm&&pin.length>=4?'var(--red)':'var(--black-border)'}`,
              borderRadius:'var(--radius-sm)',transition:'all 0.15s',opacity:loading?0.5:1
            }}>{loading&&isConfirm?'...':key}</button>
          )
        })}
      </div>
      <div style={{fontSize:12,color:'var(--gray)',marginTop:-8}}>Enter your staff PIN</div>
    </div>
  )
}
