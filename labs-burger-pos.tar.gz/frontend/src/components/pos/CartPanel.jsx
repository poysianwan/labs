import { useCartStore } from '../../stores/cartStore.js'

export default function CartPanel({ onCheckout }) {
  const { items, removeItem, updateQuantity, updateNotes, clearCart, getTotal, getItemCount } = useCartStore()
  const total = getTotal()
  const count = getItemCount()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>

      {/* Cart header */}
      <div style={{ padding: '14px 16px', borderBottom: '1px solid #2a2a2a', display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexShrink: 0 }}>
        <div style={{ fontWeight: 700, fontSize: 15 }}>
          Order
          {count > 0 && <span style={{ marginLeft: 8, background: '#CC0000', color: '#fff', borderRadius: 20, fontSize: 11, padding: '2px 8px', fontWeight: 700 }}>{count}</span>}
        </div>
        {items.length > 0 && (
          <button onClick={clearCart} style={{ fontSize: 12, color: '#666', background: 'none', padding: '4px 8px', borderRadius: 6, border: '1px solid #333' }}>
            Clear
          </button>
        )}
      </div>

      {/* Items list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {items.length === 0 ? (
          <div style={{ textAlign: 'center', color: '#444', paddingTop: 48, fontSize: 13 }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>🛒</div>
            Tap a product to add
          </div>
        ) : (
          items.map(item => (
            <CartItem
              key={item.product_id}
              item={item}
              onRemove={() => removeItem(item.product_id)}
              onQtyChange={(q) => updateQuantity(item.product_id, q)}
              onNotesChange={(n) => updateNotes(item.product_id, n)}
            />
          ))
        )}
      </div>

      {/* Total + checkout */}
      <div style={{ padding: 16, borderTop: '1px solid #2a2a2a', flexShrink: 0 }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 14, alignItems: 'baseline' }}>
          <span style={{ fontSize: 14, color: '#888' }}>TOTAL</span>
          <span style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 32, color: '#FFD700', letterSpacing: 1 }}>
            ₱{total.toFixed(2)}
          </span>
        </div>
        <button
          onClick={onCheckout}
          disabled={items.length === 0}
          style={{
            width: '100%', padding: '16px', background: items.length === 0 ? '#1a1a1a' : '#CC0000',
            color: items.length === 0 ? '#444' : '#fff', borderRadius: 12, fontSize: 16,
            fontWeight: 700, letterSpacing: 1, border: 'none',
            transition: 'background 0.2s'
          }}
        >
          CHARGE ₱{total.toFixed(2)}
        </button>
      </div>
    </div>
  )
}

function CartItem({ item, onRemove, onQtyChange, onNotesChange }) {
  return (
    <div style={{ padding: '10px 16px', borderBottom: '1px solid #222' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        {/* Qty controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexShrink: 0 }}>
          <button
            onClick={() => onQtyChange(item.quantity - 1)}
            style={{ width: 28, height: 28, borderRadius: 8, background: '#333', color: '#fff', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >−</button>
          <span style={{ fontSize: 15, fontWeight: 700, minWidth: 20, textAlign: 'center' }}>{item.quantity}</span>
          <button
            onClick={() => onQtyChange(item.quantity + 1)}
            style={{ width: 28, height: 28, borderRadius: 8, background: '#CC0000', color: '#fff', fontSize: 16, display: 'flex', alignItems: 'center', justifyContent: 'center' }}
          >+</button>
        </div>

        {/* Item name + price */}
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 13, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{item.name}</div>
          <div style={{ fontSize: 12, color: '#FFD700' }}>₱{(item.unit_price * item.quantity).toFixed(2)}</div>
        </div>

        {/* Remove */}
        <button onClick={onRemove} style={{ color: '#555', background: 'none', fontSize: 16, padding: 4, flexShrink: 0 }}>✕</button>
      </div>

      {/* Notes field */}
      <input
        placeholder="Special instructions..."
        value={item.notes}
        onChange={e => onNotesChange(e.target.value)}
        style={{
          marginTop: 6, width: '100%', background: '#1a1a1a', border: '1px solid #333',
          borderRadius: 6, padding: '5px 10px', fontSize: 12, color: '#aaa'
        }}
      />
    </div>
  )
}
