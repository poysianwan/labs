import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import { v4 as uuidv4 } from 'uuid'
import { useAuthStore } from '../../stores/authStore.js'
import { useCartStore } from '../../stores/cartStore.js'
import { getProducts, getCategories, saveOrderOffline, getAppState } from '../../db/index.js'
import { api } from '../../utils/apiClient.js'
import { flushQueue } from '../../utils/syncEngine.js'
import { useOnlineStatus } from '../../hooks/useOnlineStatus.js'
import PaymentModal from '../payment/PaymentModal.jsx'
import CartPanel from './CartPanel.jsx'

export default function POSScreen() {
  const { user, logout, isAdmin } = useAuthStore()
  const { addItem, getItemCount } = useCartStore()
  const [products, setProducts] = useState([])
  const [categories, setCategories] = useState([])
  const [activeCategory, setActiveCategory] = useState(null)
  const [showPayment, setShowPayment] = useState(false)
  const [showCart, setShowCart] = useState(false)
  const [currentShift, setCurrentShift] = useState(null)
  const [lastOrderNum, setLastOrderNum] = useState(null)
  const [orderSuccess, setOrderSuccess] = useState(false)
  const isOnline = useOnlineStatus()
  const navigate = useNavigate()

  useEffect(() => {
    const load = async () => {
      const [prods, cats] = await Promise.all([getProducts(), getCategories()])
      setProducts(prods)
      setCategories(cats.sort((a, b) => a.sort_order - b.sort_order))
      if (cats.length) setActiveCategory(cats[0].id)
      const shift = await getAppState('current_shift')
      setCurrentShift(shift)
    }
    load()
  }, [])

  const filteredProducts = activeCategory
    ? products.filter(p => p.category_id === activeCategory && !p.deleted_at)
    : products.filter(p => !p.deleted_at)

  const handleCheckout = useCallback(async (paymentData) => {
    const { items, getTotal, clearCart } = useCartStore.getState()
    const orderId = uuidv4()
    const order = {
      id: orderId,
      user_id: user.id,
      shift_id: currentShift?.id || null,
      dining_type: paymentData.dining_type,
      items: items.map(i => ({ product_id: i.product_id, quantity: i.quantity, unit_price: i.unit_price, notes: i.notes })),
      payment: { method: paymentData.method, amount: paymentData.amount, change_given: paymentData.change_given, reference_note: paymentData.reference_note },
      created_at: new Date().toISOString()
    }

    // Always save offline first
    await saveOrderOffline(order)

    // Try sync immediately if online
    if (isOnline) {
      try {
        const result = await api.createOrder(order)
        setLastOrderNum(result.order_number)
        // Mark synced in IDB
        const { markOrderSynced } = await import('../../db/index.js')
        await markOrderSynced(orderId)
      } catch (err) {
        if (err.message !== 'DUPLICATE_ORDER') console.warn('Online order failed, will sync later:', err)
      }
    }

    clearCart()
    setShowPayment(false)
    setShowCart(false)
    setOrderSuccess(true)
    setTimeout(() => setOrderSuccess(false), 2500)
    if (isOnline) flushQueue()
  }, [user, currentShift, isOnline])

  const handleLogout = async () => {
    logout()
    navigate('/login')
  }

  const itemCount = getItemCount()

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', background: '#0f0f0f', overflow: 'hidden' }}>

      {/* Top bar */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '0 16px', height: 52, background: '#CC0000', flexShrink: 0 }}>
        <div style={{ fontFamily: "'Bebas Neue', cursive", fontSize: 26, color: '#FFD700', letterSpacing: 2 }}>LABS BURGER</div>
        <div style={{ flex: 1 }} />

        {/* Online status */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: isOnline ? '#86efac' : '#fca5a5' }}>
          <div style={{ width: 8, height: 8, borderRadius: '50%', background: isOnline ? '#22c55e' : '#ef4444' }} />
          {isOnline ? 'Online' : 'Offline'}
        </div>

        {/* Cashier name */}
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.8)', padding: '4px 10px', background: 'rgba(0,0,0,0.2)', borderRadius: 20 }}>
          {user?.name}
        </div>

        {isAdmin() && (
          <button onClick={() => navigate('/admin')} style={{ padding: '6px 14px', background: '#FFD700', color: '#000', borderRadius: 8, fontSize: 12, fontWeight: 700 }}>
            Admin
          </button>
        )}

        <button onClick={handleLogout} style={{ padding: '6px 12px', background: 'rgba(0,0,0,0.3)', color: '#fff', borderRadius: 8, fontSize: 12 }}>
          Logout
        </button>
      </div>

      {/* Order success flash */}
      {orderSuccess && (
        <div style={{
          position: 'absolute', top: 64, left: '50%', transform: 'translateX(-50%)',
          background: '#22c55e', color: '#fff', padding: '10px 24px', borderRadius: 12,
          fontWeight: 700, fontSize: 15, zIndex: 100,
          animation: 'fadeIn 0.2s ease'
        }}>
          ✓ Order {lastOrderNum || 'saved'}{isOnline ? '' : ' (offline)'}
        </div>
      )}

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

        {/* Left: Category tabs + Product grid */}
        <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>

          {/* Category sidebar */}
          <div style={{ width: 100, background: '#1a1a1a', display: 'flex', flexDirection: 'column', gap: 4, padding: 8, overflowY: 'auto', flexShrink: 0 }}>
            <button
              onClick={() => setActiveCategory(null)}
              style={{
                padding: '12px 8px', borderRadius: 10, fontSize: 12, fontWeight: 600,
                background: !activeCategory ? '#CC0000' : '#252525',
                color: !activeCategory ? '#fff' : '#888',
                border: 'none', textAlign: 'center'
              }}
            >
              All
            </button>
            {categories.map(cat => (
              <button
                key={cat.id}
                onClick={() => setActiveCategory(cat.id)}
                style={{
                  padding: '12px 8px', borderRadius: 10, fontSize: 12, fontWeight: 600,
                  background: activeCategory === cat.id ? '#CC0000' : '#252525',
                  color: activeCategory === cat.id ? '#fff' : '#aaa',
                  border: 'none', textAlign: 'center', lineHeight: 1.3
                }}
              >
                {cat.name}
              </button>
            ))}
          </div>

          {/* Product grid */}
          <div style={{ flex: 1, overflowY: 'auto', padding: 12, display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', gap: 10, alignContent: 'start' }}>
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} onAdd={() => addItem(product)} />
            ))}
            {filteredProducts.length === 0 && (
              <div style={{ gridColumn: '1/-1', textAlign: 'center', color: '#444', paddingTop: 40, fontSize: 14 }}>
                No products in this category
              </div>
            )}
          </div>
        </div>

        {/* Right: Cart panel (always visible on landscape) */}
        <div style={{ width: 320, background: '#1a1a1a', borderLeft: '1px solid #2a2a2a', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
          <CartPanel onCheckout={() => setShowPayment(true)} />
        </div>
      </div>

      {/* Payment modal */}
      {showPayment && (
        <PaymentModal
          total={useCartStore.getState().getTotal()}
          onConfirm={handleCheckout}
          onCancel={() => setShowPayment(false)}
        />
      )}
    </div>
  )
}

function ProductCard({ product, onAdd }) {
  const unavailable = !product.is_available

  return (
    <button
      onClick={unavailable ? undefined : onAdd}
      disabled={unavailable}
      style={{
        background: unavailable ? '#1a1a1a' : '#252525',
        border: `1.5px solid ${unavailable ? '#222' : '#333'}`,
        borderRadius: 12,
        padding: 14,
        textAlign: 'left',
        color: unavailable ? '#444' : '#fff',
        cursor: unavailable ? 'not-allowed' : 'pointer',
        transition: 'all 0.1s',
        display: 'flex', flexDirection: 'column', gap: 6,
        minHeight: 100,
        position: 'relative',
        overflow: 'hidden'
      }}
      onMouseEnter={e => { if (!unavailable) e.currentTarget.style.borderColor = '#CC0000' }}
      onMouseLeave={e => { if (!unavailable) e.currentTarget.style.borderColor = '#333' }}
    >
      {product.is_combo && (
        <span style={{ position: 'absolute', top: 8, right: 8, fontSize: 10, background: '#FFD700', color: '#000', padding: '2px 6px', borderRadius: 20, fontWeight: 700 }}>COMBO</span>
      )}
      <div style={{ fontSize: 14, fontWeight: 600, lineHeight: 1.3, paddingRight: product.is_combo ? 48 : 0 }}>{product.name}</div>
      <div style={{ fontSize: 18, fontWeight: 700, color: unavailable ? '#444' : '#FFD700', fontFamily: "'Bebas Neue', cursive", letterSpacing: 1 }}>
        ₱{parseFloat(product.price).toFixed(2)}
      </div>
      {unavailable && <div style={{ fontSize: 11, color: '#555', fontWeight: 600 }}>UNAVAILABLE</div>}
    </button>
  )
}
