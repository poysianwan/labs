# 🍔 Labs Burger POS

Production-ready POS system for Labs Burger. Offline-first, tablet-optimized, built with React + Node.js + PostgreSQL.

---

## Quick Start

### 1. Prerequisites
- Node.js 18+
- PostgreSQL 14+
- A tablet (Android/iPad) or desktop browser

### 2. Database Setup
```bash
# Create the database
psql -U postgres -c "CREATE DATABASE labs_burger;"
```

### 3. Backend Setup
```bash
cd backend
cp .env.example .env
# Edit .env — set your DATABASE_URL and JWT_SECRET

npm install
npm run migrate     # Creates all tables + seeds test data
npm run dev         # Starts API on port 3001
```

### 4. Frontend Setup
```bash
cd frontend
npm install
npm run dev         # Starts PWA on port 5173
```

### 5. Open the POS
Go to `http://localhost:5173` on your tablet browser.

**Default PINs (from seed data):**
- Owner (Admin): `0000`
- Cashier 1: `0000`

> Change PINs immediately in production via the database.

---

## Project Structure

```
labs-burger/
├── backend/
│   └── src/
│       ├── db/
│       │   ├── index.js          # PostgreSQL connection
│       │   └── migrate.js        # All tables + seed data
│       ├── middleware/
│       │   └── auth.js           # JWT + role guard
│       ├── routes/
│       │   ├── auth.js           # PIN login
│       │   ├── orders.js         # Create, list, void
│       │   ├── sync.js           # Offline sync + snapshot
│       │   ├── inventory.js      # Ingredients, restock, recipes
│       │   └── reports.js        # Sales, shifts, stock
│       ├── services/
│       │   └── bom.js            # Bill of Materials engine
│       └── index.js              # Express app
│
└── frontend/
    └── src/
        ├── components/
        │   ├── auth/LoginScreen.jsx      # PIN numpad login
        │   ├── pos/POSScreen.jsx         # Main POS grid
        │   ├── cart/CartPanel.jsx        # Cart + totals
        │   ├── payment/PaymentModal.jsx  # Cash / GCash
        │   └── admin/AdminDashboard.jsx  # Admin panel
        ├── stores/
        │   ├── authStore.js      # Zustand auth state
        │   └── cartStore.js      # Zustand cart state
        ├── db/
        │   └── index.js          # IndexedDB (offline store)
        └── utils/
            ├── api.js            # All API calls
            ├── sync.js           # Sync engine
            └── printer.js        # Receipt printing
```

---

## Key Features

| Feature | How it works |
|---|---|
| Offline orders | Written to IndexedDB immediately, synced when back online |
| BOM deduction | Product recipe table maps items to ingredients |
| GCash payments | QR outside counter, cashier records manually |
| Receipt printing | ESC/POS bridge or browser print fallback |
| Role security | JWT with role claim, admin routes blocked for cashiers |
| Cash accountability | Shift open/close with variance calculation |

---

## Production Deployment

### Backend (Railway / Render / VPS)
```bash
cd backend
# Set environment variables:
# DATABASE_URL=postgresql://...
# JWT_SECRET=<strong-random-secret>
# NODE_ENV=production
# FRONTEND_URL=https://your-domain.com

npm start
```

### Frontend (Netlify / Vercel / static host)
```bash
cd frontend
# Set VITE_API_URL if backend is on different domain
npm run build
# Deploy /dist folder
```

### PWA Installation on Tablet
1. Open the app URL in Chrome (Android) or Safari (iPad)
2. Tap "Add to Home Screen"
3. App opens fullscreen, landscape mode

### Receipt Printer Bridge
```bash
# Install on a local PC/Raspberry Pi on the same network
npm install node-thermal-printer express
# Configure printer IP or USB path
# Run: node printer-bridge.js
```

---

## Default Seed Data

### Products
| Name | Price | Type |
|---|---|---|
| Classic Burger | ₱89 | Single |
| Cheeseburger | ₱99 | Single |
| Double Patty | ₱129 | Single |
| Classic Combo | ₱149 | Combo |
| Cheese Combo | ₱169 | Combo |
| Coke | ₱39 | Drink |
| Iced Tea | ₱35 | Drink |
| Fries | ₱59 | Side |

### Ingredients (initial stock: 100 each)
Beef Patty, Burger Bun, Cheddar Cheese, Lettuce, Tomato, French Fries, Soft Drink Cup, Sauce Packet

---

## Security Notes

- Change default PINs before going live
- Use HTTPS in production (required for PWA)
- Set a strong `JWT_SECRET` (32+ random characters)
- Enable PostgreSQL SSL in production
- Audit logs track all admin actions
