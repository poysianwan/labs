import express from 'express'
import cors from 'cors'
import dotenv from 'dotenv'
import authRoutes from './routes/auth.js'
import orderRoutes from './routes/orders.js'
import syncRoutes from './routes/sync.js'
import inventoryRoutes from './routes/inventory.js'
import reportRoutes from './routes/reports.js'

dotenv.config()

const app = express()

app.use(cors({
  origin: process.env.FRONTEND_URL || 'http://localhost:5173',
  credentials: true
}))
app.use(express.json({ limit: '5mb' }))

// Health check
app.get('/health', (req, res) => res.json({ ok: true, time: new Date() }))

// Routes
app.use('/api/auth', authRoutes)
app.use('/api/orders', orderRoutes)
app.use('/api/sync', syncRoutes)
app.use('/api/inventory', inventoryRoutes)
app.use('/api/reports', reportRoutes)

// Global error handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err)
  res.status(500).json({ error: 'SERVER_ERROR', message: err.message })
})

const PORT = process.env.PORT || 3001
app.listen(PORT, () => {
  console.log(`🍔 Labs Burger API running on port ${PORT}`)
})

export default app
