import { Router } from 'express'
import { query } from '../db/index.js'
import { authenticate, requireAdmin } from '../middleware/auth.js'

const router = Router()

// POST /api/shifts/start
router.post('/shifts/start', authenticate, async (req, res) => {
  const { opening_cash = 0 } = req.body
  try {
    // Close any open shift for this user first
    await query(
      `UPDATE shifts SET ended_at = NOW() WHERE user_id = $1 AND ended_at IS NULL`,
      [req.user.id]
    )
    const { rows } = await query(
      `INSERT INTO shifts (user_id, opening_cash) VALUES ($1, $2) RETURNING *`,
      [req.user.id, opening_cash]
    )
    res.status(201).json({ shift_id: rows[0].id, started_at: rows[0].started_at })
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// POST /api/shifts/:id/end
router.post('/shifts/:id/end', authenticate, async (req, res) => {
  const { closing_cash = 0 } = req.body
  try {
    // Calculate expected cash from this shift
    const { rows: cashData } = await query(
      `SELECT COALESCE(SUM(p.amount - p.change_given), 0) AS cash_collected
       FROM orders o JOIN payments p ON p.order_id = o.id
       WHERE o.shift_id = $1 AND p.method = 'cash' AND o.status = 'completed'`,
      [req.params.id]
    )

    const { rows: shift } = await query('SELECT opening_cash FROM shifts WHERE id = $1', [req.params.id])
    if (!shift.length) return res.status(404).json({ error: 'NOT_FOUND' })

    const expected = parseFloat(shift[0].opening_cash) + parseFloat(cashData[0].cash_collected)
    const variance = closing_cash - expected

    await query(
      `UPDATE shifts SET ended_at = NOW(), closing_cash = $1 WHERE id = $2`,
      [closing_cash, req.params.id]
    )

    // Summary
    const { rows: summary } = await query(
      `SELECT
        COUNT(*) AS total_orders,
        COALESCE(SUM(o.total), 0) AS total_sales,
        COALESCE(SUM(CASE WHEN p.method='cash' THEN p.amount - p.change_given ELSE 0 END), 0) AS cash_sales,
        COALESCE(SUM(CASE WHEN p.method='gcash' THEN p.amount ELSE 0 END), 0) AS gcash_sales
       FROM orders o JOIN payments p ON p.order_id = o.id
       WHERE o.shift_id = $1 AND o.status = 'completed'`,
      [req.params.id]
    )

    res.json({
      shift_id: req.params.id,
      ...summary[0],
      expected_cash: expected,
      closing_cash,
      variance
    })
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// GET /api/reports/sales
router.get('/sales', authenticate, requireAdmin, async (req, res) => {
  const { from, to } = req.query
  const fromDate = from || new Date().toISOString().split('T')[0]
  const toDate = to || fromDate

  try {
    const [summary, topProducts, hourly] = await Promise.all([
      query(
        `SELECT COUNT(*) AS total_orders,
                COALESCE(SUM(o.total), 0) AS total_revenue,
                COALESCE(SUM(CASE WHEN p.method='cash' THEN p.amount - p.change_given ELSE 0 END), 0) AS cash_revenue,
                COALESCE(SUM(CASE WHEN p.method='gcash' THEN p.amount ELSE 0 END), 0) AS gcash_revenue
         FROM orders o JOIN payments p ON p.order_id = o.id
         WHERE o.status = 'completed'
           AND DATE(o.created_at AT TIME ZONE 'Asia/Manila') BETWEEN $1 AND $2`,
        [fromDate, toDate]
      ),
      query(
        `SELECT pr.name, SUM(oi.quantity) AS qty_sold, SUM(oi.quantity * oi.unit_price) AS revenue
         FROM order_items oi
         JOIN products pr ON pr.id = oi.product_id
         JOIN orders o ON o.id = oi.order_id
         WHERE o.status = 'completed'
           AND DATE(o.created_at AT TIME ZONE 'Asia/Manila') BETWEEN $1 AND $2
         GROUP BY pr.name ORDER BY qty_sold DESC LIMIT 10`,
        [fromDate, toDate]
      ),
      query(
        `SELECT EXTRACT(HOUR FROM o.created_at AT TIME ZONE 'Asia/Manila') AS hour,
                COUNT(*) AS orders
         FROM orders o
         WHERE o.status = 'completed'
           AND DATE(o.created_at AT TIME ZONE 'Asia/Manila') BETWEEN $1 AND $2
         GROUP BY hour ORDER BY hour`,
        [fromDate, toDate]
      )
    ])

    res.json({
      ...summary.rows[0],
      top_products: topProducts.rows,
      hourly: hourly.rows,
      from: fromDate,
      to: toDate
    })
  } catch (err) {
    console.error(err)
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// GET /api/reports/stock-movements
router.get('/stock-movements', authenticate, requireAdmin, async (req, res) => {
  const { ingredient_id, from, to } = req.query
  const fromDate = from || new Date().toISOString().split('T')[0]
  const toDate = to || fromDate

  try {
    let sql = `SELECT sm.*, i.name AS ingredient_name, i.unit
               FROM stock_movements sm JOIN ingredients i ON i.id = sm.ingredient_id
               WHERE DATE(sm.created_at AT TIME ZONE 'Asia/Manila') BETWEEN $1 AND $2`
    const params = [fromDate, toDate]

    if (ingredient_id) { params.push(ingredient_id); sql += ` AND sm.ingredient_id = $${params.length}` }
    sql += ` ORDER BY sm.created_at DESC`

    const { rows } = await query(sql, params)
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

export default router
