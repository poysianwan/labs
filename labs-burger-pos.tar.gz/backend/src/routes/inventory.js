import { Router } from 'express'
import { query, transaction } from '../db/index.js'
import { authenticate, requireAdmin } from '../middleware/auth.js'

const router = Router()

// GET /api/ingredients
router.get('/', authenticate, requireAdmin, async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT *, current_stock < low_stock_alert AS is_low FROM ingredients
       WHERE deleted_at IS NULL ORDER BY name`
    )
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// POST /api/ingredients — create ingredient
router.post('/', authenticate, requireAdmin, async (req, res) => {
  const { name, unit, current_stock = 0, low_stock_alert = 10 } = req.body
  if (!name || !unit) return res.status(400).json({ error: 'VALIDATION_ERROR' })
  try {
    const { rows } = await query(
      `INSERT INTO ingredients (name, unit, current_stock, low_stock_alert)
       VALUES ($1, $2, $3, $4) RETURNING *`,
      [name, unit, current_stock, low_stock_alert]
    )
    res.status(201).json(rows[0])
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// PUT /api/ingredients/:id
router.put('/:id', authenticate, requireAdmin, async (req, res) => {
  const { name, unit, low_stock_alert } = req.body
  try {
    const { rows } = await query(
      `UPDATE ingredients SET
        name = COALESCE($1, name),
        unit = COALESCE($2, unit),
        low_stock_alert = COALESCE($3, low_stock_alert)
       WHERE id = $4 AND deleted_at IS NULL RETURNING *`,
      [name, unit, low_stock_alert, req.params.id]
    )
    if (!rows.length) return res.status(404).json({ error: 'NOT_FOUND' })
    res.json(rows[0])
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// POST /api/ingredients/:id/restock
router.post('/:id/restock', authenticate, requireAdmin, async (req, res) => {
  const { quantity, note = 'manual restock' } = req.body
  if (!quantity || quantity <= 0) return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'quantity must be > 0' })

  try {
    const result = await transaction(async (client) => {
      const { rows } = await client.query(
        `UPDATE ingredients SET current_stock = current_stock + $1
         WHERE id = $2 AND deleted_at IS NULL RETURNING id, name, current_stock`,
        [quantity, req.params.id]
      )
      if (!rows.length) throw Object.assign(new Error('NOT_FOUND'), { status: 404 })

      await client.query(
        `INSERT INTO stock_movements (ingredient_id, movement_type, quantity, note)
         VALUES ($1, 'restock', $2, $3)`,
        [req.params.id, quantity, note]
      )

      return rows[0]
    })

    res.json({ ingredient_id: req.params.id, new_stock: result.current_stock })
  } catch (err) {
    if (err.message === 'NOT_FOUND') return res.status(404).json({ error: 'NOT_FOUND' })
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// GET /api/products — full list
router.get('/products', authenticate, async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT p.*, c.name AS category_name FROM products p
       LEFT JOIN categories c ON c.id = p.category_id
       WHERE p.deleted_at IS NULL ORDER BY c.sort_order, p.name`
    )
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// PUT /api/products/:id
router.put('/products/:id', authenticate, requireAdmin, async (req, res) => {
  const { name, price, is_available, image_url } = req.body
  try {
    const { rows: before } = await query('SELECT * FROM products WHERE id = $1', [req.params.id])
    if (!before.length) return res.status(404).json({ error: 'NOT_FOUND' })

    const { rows } = await query(
      `UPDATE products SET
        name = COALESCE($1, name),
        price = COALESCE($2, price),
        is_available = COALESCE($3, is_available),
        image_url = COALESCE($4, image_url)
       WHERE id = $5 RETURNING *`,
      [name, price, is_available, image_url, req.params.id]
    )

    await query(
      `INSERT INTO audit_logs (user_id, action, table_name, record_id, old_value, new_value)
       VALUES ($1, 'update_product', 'products', $2, $3, $4)`,
      [req.user.id, req.params.id, JSON.stringify(before[0]), JSON.stringify(rows[0])]
    )

    res.json(rows[0])
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// GET /api/products/:id/recipe
router.get('/products/:id/recipe', authenticate, async (req, res) => {
  try {
    const { rows } = await query(
      `SELECT pr.*, i.name AS ingredient_name, i.unit FROM product_recipes pr
       JOIN ingredients i ON i.id = pr.ingredient_id
       WHERE pr.product_id = $1`, [req.params.id]
    )
    res.json(rows)
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

// PUT /api/products/:id/recipe — replace entire recipe
router.put('/products/:id/recipe', authenticate, requireAdmin, async (req, res) => {
  const { ingredients } = req.body // [{ ingredient_id, quantity_used }]
  if (!Array.isArray(ingredients)) return res.status(400).json({ error: 'VALIDATION_ERROR' })

  try {
    await transaction(async (client) => {
      await client.query('DELETE FROM product_recipes WHERE product_id = $1', [req.params.id])
      for (const ing of ingredients) {
        await client.query(
          `INSERT INTO product_recipes (product_id, ingredient_id, quantity_used)
           VALUES ($1, $2, $3)`,
          [req.params.id, ing.ingredient_id, ing.quantity_used]
        )
      }
    })
    res.json({ product_id: req.params.id, ingredients })
  } catch (err) {
    res.status(500).json({ error: 'SERVER_ERROR' })
  }
})

export default router
